#!/usr/bin/env python3
"""
Comprehensive Test Suite for High-End Specialized Package
"""

import sys
import importlib
import traceback

def test_imports():
    """Test that all major modules can be imported."""
    
    modules_to_test = [
        "algorithms.quantum_annealing_optimization",
        "algorithms.advanced_monte_carlo_tree_search", 
        "algorithms.transformer_attention_mechanism",
        "algorithms.automated_market_maker",
        "algorithms.genetic_algorithm_adaptive",
        "functions.advanced_options_pricing",
        "functions.portfolio_risk_management",
        "functions.neural_network_activations",
        "equations.black_scholes_merton_pde",
        "equations.capital_asset_pricing_model",
        "equations.modern_portfolio_theory"
    ]
    
    print("Testing imports...")
    passed = 0
    failed = 0
    
    for module_name in modules_to_test:
        try:
            importlib.import_module(module_name)
            print(f"  ✓ {module_name}")
            passed += 1
        except Exception as e:
            print(f"  ✗ {module_name}: {str(e)}")
            failed += 1
    
    print(f"\nImport tests: {passed} passed, {failed} failed")
    return failed == 0

def test_basic_functionality():
    """Test basic functionality of key components."""
    
    print("\nTesting basic functionality...")
    
    try:
        # Test portfolio optimization
        from algorithms.quantum_annealing_optimization import QuantumAnnealingOptimizer
        print("  ✓ Quantum annealing optimizer loaded")
        
        # Test options pricing
        from functions.advanced_options_pricing import AdvancedOptionsPricer, OptionParameters
        pricer = AdvancedOptionsPricer()
        print("  ✓ Options pricer loaded")
        
        # Test activation functions
        from functions.neural_network_activations import ActivationAnalyzer
        analyzer = ActivationAnalyzer()
        print("  ✓ Activation analyzer loaded")
        
        # Test Modern Portfolio Theory
        from equations.modern_portfolio_theory import ModernPortfolioTheory
        import numpy as np
        
        # Quick functionality test
        returns = np.random.normal(0.001, 0.02, (100, 3))
        mpt = ModernPortfolioTheory(returns)
        min_var = mpt.minimum_variance_portfolio()
        print("  ✓ Portfolio optimization working")
        
        print("\nAll basic functionality tests passed!")
        return True
        
    except Exception as e:
        print(f"  ✗ Functionality test failed: {str(e)}")
        traceback.print_exc()
        return False

def main():
    """Run all tests."""
    
    print("=" * 60)
    print("HIGH-END SPECIALIZED PACKAGE TEST SUITE")
    print("=" * 60)
    
    # Test imports
    imports_ok = test_imports()
    
    # Test functionality  
    functionality_ok = test_basic_functionality()
    
    # Summary
    print("\n" + "=" * 60)
    if imports_ok and functionality_ok:
        print("🎉 ALL TESTS PASSED - Package is ready to use!")
    else:
        print("❌ Some tests failed - Please check the error messages above")
    print("=" * 60)

if __name__ == "__main__":
    main()
